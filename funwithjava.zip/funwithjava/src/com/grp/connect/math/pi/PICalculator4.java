package com.grp.connect.math.pi;

	import java.math.BigDecimal;
	import java.math.MathContext;

	public class PICalculator4 {
	  public static void main(String[] args) {
	    // Set the precision to 100 decimal places
	    MathContext mc = new MathContext(100);

	    // Initialize the sum to 0
	    BigDecimal sum = new BigDecimal(0, mc);

	    // Set the number of terms to calculate
	    int n = 100;

	    // Loop over the terms of the series
	    for (int k = 0; k < n; k++) {
	      // Calculate the current term of the series
	      BigDecimal term1 = new BigDecimal(4, mc).divide(new BigDecimal(8 * k + 1, mc), mc);
	      BigDecimal term2 = new BigDecimal(2, mc).divide(new BigDecimal(8 * k + 4, mc), mc);
	      BigDecimal term3 = new BigDecimal(1, mc).divide(new BigDecimal(8 * k + 5, mc), mc);
	      BigDecimal term4 = new BigDecimal(1, mc).divide(new BigDecimal(8 * k + 6, mc), mc);
	      BigDecimal term = term1.subtract(term2, mc).subtract(term3, mc).subtract(term4, mc);

	      // Add the term to the sum
	      sum = sum.add(term, mc);
	    }

	    // Print the value of PI to 100 decimal places
	    System.out.println(sum);
	  }
	}
