package com.grp.connect.math.pi;


	import java.math.BigDecimal;
	import java.math.MathContext;
	import java.util.Random;

	public class PICalculator3 {
	  public static void main(String[] args) {
	    // Set the precision to 100 decimal places
	    MathContext mc = new MathContext(100);

	    // Set the number of points to generate
	    int n = 1000000;

	    // Create a random number generator
	    Random rng = new Random();

	    // Initialize the counters for points inside and outside the quarter-circle
	    int inside = 0;
	    int outside = 0;

	    // Generate the points and count them
	    for (int i = 0; i < n; i++) {
	      // Generate a random point within the unit square
	      double x = rng.nextDouble();
	      double y = rng.nextDouble();

	      // Check if the point is inside the quarter-circle
	      if (x * x + y * y < 1) {
	        inside++;
	      } else {
	        outside++;
	      }
	    }

	    // Calculate the ratio of points inside the quarter-circle to the total number of points
	    BigDecimal ratio = new BigDecimal(inside, mc).divide(new BigDecimal(n, mc), mc);

	    // Multiply the ratio by 4 to obtain an approximation of PI
	    BigDecimal pi = ratio.multiply(new BigDecimal(4, mc), mc);

	    // Print the value of PI to 100 decimal places
	    System.out.println(pi);
	  }
	}
