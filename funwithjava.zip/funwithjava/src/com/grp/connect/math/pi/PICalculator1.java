/**
 * 
 */
package com.grp.connect.math.pi;

/**
 * @author Mr Gaurav Rajapurkar
 *
 */


	import java.math.BigDecimal;
	import java.math.MathContext;

	public class PICalculator1 {
	  public static void main(String[] args) {
	    // Set the precision to 1000 decimal places
	    MathContext mc = new MathContext(1000);

	    // Use the value of PI from the Math class as a starting point
	    BigDecimal pi = new BigDecimal(Math.PI, mc);

	    // Print the value of PI to 100 decimal places
	    System.out.println(pi);
	  }
	}

